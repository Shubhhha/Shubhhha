<?php
session_start();
$con=mysqli_connect('localhost','root','','youtube');
$id=mysqli_real_escape_string($con,$_POST['id']);

$row=mysqli_fetch_assoc(mysqli_query($con,"select * from user where id='$id'"));
$arr=array('status'=>$row['status']);
if($row['status']==1){
	$_SESSION['IS_LOGIN']='yes';
}
echo json_encode($arr); 
?>