<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<?php
$con=mysqli_connect('localhost','root','','youtube');

if(isset($_GET['id'])){
	$id=mysqli_real_escape_string($con,$_GET['id']);
	$type=mysqli_real_escape_string($con,$_GET['type']);
	if($type=='active'){
		$status=1;
	}else{
		$status=0;
	}
	mysqli_query($con,"update user set status='$status' where id='$id'");
}

$res=mysqli_query($con,"select * from user");
?>
<div class="container">
    <div class="row col-md-6 col-md-offset-2 custyle">
    <table class="table table-striped custab">
    <thead>
    
	<tr>
		<th>ID</th>
		<th>Username</th>
		<th>Password</th>
		<th class="text-center">Action</th>
	</tr>
    </thead>
			<?php while($row=mysqli_fetch_assoc($res)){?>
		   <tr>
                <td><?php echo $row['id']?></td>
                <td><?php echo $row['username']?></td>
                <td><?php echo $row['password']?></td>
                <td class="text-center">
					<?php
					if($row['status']==1){
						echo "<a href='?id=".$row['id']."&type=deactive'>Active</a>";
					}else{
						echo "<a href='?id=".$row['id']."&type=active'>Deactive</a>";
					}
					?>
				</td>
            </tr>
            <?php } ?>
    </table>
    </div>
</div>