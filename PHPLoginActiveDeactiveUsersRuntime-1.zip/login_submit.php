<?php
session_start();
$con=mysqli_connect('localhost','root','','youtube');
$username=mysqli_real_escape_string($con,$_POST['username']);
$password=mysqli_real_escape_string($con,$_POST['password']);

$res=mysqli_query($con,"select * from user where username='$username' and password='$password'");

if(mysqli_num_rows($res)>0){
	$row=mysqli_fetch_assoc($res);
	if($row['status']==1){
		$_SESSION['IS_LOGIN']='yes';
		$arr=array('status'=>'success');
	}else{
		$arr=array('status'=>'wait','id'=>$row['id']);
	}	
}else{
	$arr=array('status'=>'error','msg'=>'Please enter valid login details');
}
echo json_encode($arr);
?>